#Ejercicio para el 2 de Febrero

#1.- Descargar de la carpeta compartida el archivo Ventas_vs_Publicidad
#2.- Hacer un scatterplot comparando la venta con la publicidad total
#3.- Gráfico de Línea para ver la evolución de la publicidad en TV, radio, periódico y redes
#4.- Barplot del total de ventas con y sin famoso 

#Importación de librerías
import plotly.offline as pyo
import plotly.graph_objs as go
import pandas as pd

#Carga de datos
df_ventas = pd.read_excel(r'datasets\Venta_vs_Publicidad.xlsx')

df_ventas.columns
