# -*- coding: utf-8 -*-
"""boxplot.py
"""

import pandas as pd
import matplotlib.pyplot as plt

#https://mk0codingwithmaxskac.kinstacdn.com/wp-content/uploads/2019/11/box-plot-vertical-horizontal-1.png

edad = [12,20,50,80,20,41,40,23,45,67,87,14,10]

edad = [41,25,23,35,42,24,31,39,36,35]
plt.boxplot(edad)

df_temp = pd.read_excel(r'datasets\Temperaturas.xlsx',sheet_name="Sheet1")

df_temp.head(3)

#Creo una variable T.Promedio 
df_temp["T.Promedio"] = (df_temp["T. Máxima"]+df_temp["T.Mínima"])/2

df_temp["GradienteTermica"] = df_temp["T. Máxima"] - df_temp["T.Mínima"]

df_temp.head(3)

#Creo un boxplot de la columna T.Promedio
df_temp.boxplot(column="T.Promedio")

df_temp.boxplot(column="GradienteTermica")

#Boxplot creado agrupado ciudad
df_temp.boxplot(column="T.Promedio",by="Ciudad")

df_temp.boxplot(column="GradienteTermica",by="Ciudad")


"""# Ejercicio
¿Cuáles son los 2 distritos con mayor varianza en su tráfico peatonal?
Argenzuela - Centro

¿Cuál es el distrito donde es más estable el tráfico de personas?
Latina

¿Cuál es el distrito que alcanza mayor valor de tráfico peatonal?
Argenzuela

¿Se observan outliers en nuestros datos?

Si 

"""


import matplotlib.pyplot as plt

df_peatones = pd.read_csv(r'datasets\PEATONES_2020_mod.csv',encoding = "ISO-8859-1",delimiter=';')

df_peatones.head()

df_peatones.columns

df_peatones.boxplot(column="PEATONES",by="DISTRITO")















