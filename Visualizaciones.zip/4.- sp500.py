# -*- coding: utf-8 -*-
"""
Created on Fri Nov 20 22:57:25 2020

@author: resteves
"""
"""EJERCICIO: Visualizar la evolución de la cotización en bolsa del índice SP500  }
(delimitador csv = “,”, se quiere poner como índice la columna de fecha:  df.index = df[“Date”])
"""

import pandas as pd

df = pd.read_csv(r'datasets/SP500_data.csv',encoding = "ISO-8859-1",delimiter=',')

print(df)

#Veo las columnas
df.columns


df["Close"].plot()

print(df["Close"])

#*******************

print(df)

pd.set_option('display.max_columns', None)

#Cambio el valor del índice por la fecha

df.index

df.index = df["Date"]

print(df["Date"])

print(df)

df.index

#Visualizar la evolución de la cotización en bolsa del 
#índice SP500  

print(df["Close"])
df["Close"].plot()

df["Open"].plot()

df["Volume"].plot()
df["High"].plot()
df["Low"].plot()


