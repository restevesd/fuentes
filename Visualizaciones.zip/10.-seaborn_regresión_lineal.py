# -*- coding: utf-8 -*-
"""Seaborn Regresión lineal.py


# **Precio de las casa**
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df_casas = pd.read_excel("datasets/casas.xlsx")

df_casas

df_casas.dtypes

plt.scatter(df_casas["superficie"],df_casas["valor"])

sns.regplot(data=df_casas, x="superficie", y="valor",scatter=True, color='blue', order=1, label="Orden 1")

from scipy import stats

pendiente, intercepto, r_value, p_value, std_err = stats.linregress(df_casas["superficie"],df_casas["valor"])

sns.regplot(data=df_casas, x="superficie", y="valor", scatter=True, order=1,
            color='blue',line_kws={'label':"y={0:.1f}x+{1:.1f}".format(pendiente,intercepto)})
plt.legend()

#Cuanto valdría una casa de x m2

x = 100
y = 1159.6*x + 76657.7
y = round(y,2)
print(y)


""" **Más información**
https://seaborn.pydata.org/tutorial/regression.html 

https://seaborn.pydata.org/generated/seaborn.regplot.html

"""
