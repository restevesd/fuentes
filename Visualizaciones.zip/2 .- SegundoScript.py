# -*- coding: utf-8 -*-
"""
Created on Fri Nov 20 22:38:20 2020

@author: resteves
"""

import pandas as pd

df = pd.read_csv("datasets/gapminder.csv")

print(df)

df.columns

print(df["nombre"])

print (df["continente"])

print(df["pais"])

print(df["anio"])

print(df["expVida"])

print(df["pobl"])

print(df["PBI_PC"])


print(df[["pais","pobl","anio"]])

#lista -> [elemento1,elemento2,elemento3] 


print(df["expVida"])

df["expVida"].plot()

print(df["anio"])
df["anio"].plot()

df["pobl"].plot()

df["pobl"].sort_values()

df["pobl"].sort_values().plot()

df["PBI_PC"].plot()

df["continente"].plot()

df["pais"].plot()




