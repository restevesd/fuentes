#Importar librerías
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd
import json #librería para retornar información en formato json

app = dash.Dash()
traces = []

data_con = pd.read_csv("datasets/Casos_Diarios_Estado_Nacional_Confirmados.csv")

data_con.head()

# FASE 1: DEFINICIÓN LAYOUT

app.layout = html.Div([
                    html.Div([
                    html.Label('ESTADO'),
                    dcc.Dropdown(id='selector_estado',
                        options=[{'label': i, 'value': i} for i in data_con["ESTADO"].unique()],
                        value='MEXICO',
                        style={'width': '48%', 'display': 'inline-block'})]),
                    
                    html.Div([
                    dcc.Graph(id='grafic_confirmados',
                              style={'width': '90%'})])])

# FASE 4: Callback para actualizar gráfico de Segmento en función del dropdown de País y según selector de fechas


@app.callback(Output('graic_confirmados', 'figure'),
              [Input('selector_estado', 'value')])

def actualizar_grafico(valor):
    print(valor)
    data_estado =data_con[data_con["ESTADO"] == valor]
    print(data_estado)
    return{
            'data': [go.Scatter(x=data_con["FECHA"],
                                y=data_con["ESTADO"],
                                mode="lines")],
            'layout': go.Layout(
                title="Confirmados COVID-19",
                xaxis={'title': "Fecha"},
                yaxis={'title': "Confirmados"},
                hovermode='closest'
                )
    }
    
      
if __name__ == '_main_':
    app.run_server(port=7200)