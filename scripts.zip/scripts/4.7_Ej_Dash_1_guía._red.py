#Importar librerías
import dash
from dash import dcc
from dash import html
import plotly.graph_objs as go
import pandas as pd


#agregar gráfico de línea con el valor de cierre de la cotización del índice histórico (columna Close)
#agregar gráfico de barras con el volumen negociado de manera histórica(columna Volume)

app = dash.Dash()

# Carga datos
df_sp500 = pd.read_csv(r'datasets/SP500_data_.csv',encoding = 'ISO-8859-1',delimiter=',')



#Objetos plotly.graph
data1 = [go.Scatter(x=df_sp500["Date"],
                    y=df_sp500["Close"],
                    mode="lines+markers",
                    name="Cierre")]

layout1 = go.Layout(title="SP500 Cotización",
                    xaxis=dict(title="Fecha"),
                    yaxis=dict(title="SP500 Cotización"))


data2 = [go.Bar(x=df_sp500["Date"],
                y=df_sp500["Volume"],
                name="Valor Negociado")]

layout2 = go.Layout(title="Volumen negociado de manera hist�rica",
                    xaxis=dict(title="Fecha"),
                    yaxis=dict(title="Valor Negociado"))

#Definición del layout de la app a partir de componentes HTML y Core
app.layout = html.Div([
                    dcc.Graph(id='scatterplot',
                    figure = {'data':data1,
                            'layout':layout1}
                    ),
                    dcc.Graph(id='bar',
                    figure = {'data':data2,
                            'layout':layout2}
                              )
                    ])

#Sentencias para abrir el servidor al ejecutar este script
if __name__ == '__main__':
    app.run_server(port=8000)
