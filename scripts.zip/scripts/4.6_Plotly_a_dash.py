#Importación de librerías
from dash import dcc
from dash import html
import dash
import plotly.graph_objs as go
import pandas as pd

#Creación de la app de dash
app = dash.Dash()

# Carga datos
df_iris = pd.read_csv(r'datasets/iris_dataset.csv',encoding = 'ISO-8859-1',delimiter=',')

df_iris.columns

df_iris.head(2)

#Objetos plotly.graph
data1 = [go.Scatter(x=df_iris["longitud_pétalo"],
                    y=df_iris["anchura_pétalo"],
                    mode="markers",
                    marker = dict(
                            size=12,
                            symbol="circle",
                            line={"width":3} #línea del marcador
                    ))]

layout1 = go.Layout(title="Iris Scatter plot Pétalo",
                    xaxis=dict(title="Longitud Pétalo"),
                    yaxis=dict(title="Anchura Pétalo"))


#Definición del layout de la app a partir de componentes HTML y Core
app.layout = html.Div([html.H1(children='Estamos Domingo'),
                       dcc.Graph(id='scatterplot',figure = {'data':data1,'layout':layout1})
                    ])

#Sentencias para abrir el servidor al ejecutar este script
if __name__ == '__main__':
    app.run_server(port=8001)
