#Importar librerías
import dash
from dash import dcc
from dash import html
import plotly.graph_objs as go
import pandas as pd

#importar SP500_data_.csv
#agregar gráfico de línea con el valor de cierre de la cotización del índice histórico (columna Close)
#agregar gráfico de barras con el volumen negociado de manera histórica(columna Volume)

app = dash.Dash()

# Carga datos
df_sp500 = pd.read_csv(r'...',encoding = 'ISO-8859-1',delimiter=',')

#Objetos plotly.graph
data1 = [go.Scatter(...)]

layout1 = go.Layout(...)

data2 = [go.Bar(...)]

layout2 = go.Layout(...)

#Definición del layout de la app a partir de componentes HTML y Core
app.layout = html.Div([
                    ...





                    ])

#Sentencias para abrir el servidor al ejecutar este script
if __name__ == '__main__':
    app.run_server()
