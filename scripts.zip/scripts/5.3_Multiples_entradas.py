#Importar librerías
import dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd

app = dash.Dash()

#Carga de datos
df = pd.read_excel(r'datasets/Info_pais.xlsx')

df.columns

columnas = df.columns #Lista con las columnas del dataframe que estarán en los dropdowns

print(columnas)

#Definición del layout de la app a partir de componentes HTML y Core
app.layout = html.Div([
                html.Div([
                dcc.Dropdown(
                    id='ejex',
                    options=[{'label': i, 'value': i} for i in columnas],
                    
                    #option =[{label:"esperanza de vida",'value':'Esperanza de vida"}]
                    value='Renta per capita' #Valor por default que aparece 
                    )
                    ],style={'width': '48%', 'display': 'inline-block'}), 
                #inline-block:incrustar elementos en la mism fila

                html.Div([
                dcc.Dropdown(
                    id='ejey',
                    options=[{'label': i, 'value': i} for i in columnas],
                    value='Esperanza de vida'
                    )
                    ],style={'width': '48%', 'float': 'right', 'display': 'inline-block'}), 
                #float:right -> para que el div se alinee a la derecha

                dcc.Graph(id='grafico_var')
], style={'padding':10})

# CREACIÓN DE GRÁFICOS E INTERACTIVIDAD
#Callback para actualizar gráfico en función de los 2 dropdowns
@app.callback(
    Output('grafico_var', 'figure'),
    [Input('ejex', 'value'), 
     Input('ejey', 'value')])

def actualizar_graf(nombre_ejex, nombre_ejey):
    return {
        'data': [go.Scatter(
            x=df[nombre_ejex], #la selección realizada en el primer dropdown
            y=df[nombre_ejey], #la selección realizada en el segundo dropdown
            text=df['Pa�s']+" "+df['Continente'],
            mode='markers',
            marker={
                'size': 15,
                'opacity': 0.5,
                'line': {'width': 0.5, 'color': 'white'}
            }
        )],
        'layout': go.Layout(
            xaxis={'title': nombre_ejex},
            yaxis={'title': nombre_ejey},
            margin={'l': 40, 'b': 40, 't': 10, 'r': 0},#especificar márgenes
            hovermode='closest'
        )
    }

#Sentencias para abrir el servidor al ejecutar este script
if __name__ == '__main__':
    app.run_server()
