#Cargar la base sp500
#Construir un gr�fico de linea que muestre el valor de cierre o apertura, seleccionado en un dropdown
#Date picker para la selecci�n de fechas

#gr�fico 1: Gr�fico de lineas con el valor de la cotizacion del Indice historico ( Close por defecto )
#Gr�fico 2: Gr�fico de barras con el volumen negociado de manera historica ( Columna volume )


#Importar libreri�as
import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
from dash.dependencies import Input, Output
import pandas as pd

app = dash.Dash()

# CARGA DE DATOS
df_sp500 = pd.read_csv(r'...',encoding = 'ISO-8859-1',delimiter=',')

# DEFINICION LAYOUT
app.layout = html.Div([
                    html.Div([
                    html.Label('Seleccion'),
                    dcc.Dropdown(id='selector',
                        ...
                    )],style={'width': '48%', 'display': 'inline-block'}),

                    html.Div([
                    html.Label('Rango fechas'),
                    dcc.DatePickerRange(...),
                    ],style={'width': '48%', 'float': 'right', 'display': 'inline-block'}),

                    ...,

                    ...


                    ])

# CREACIo�N DE GRAFICOS E INTERACTIVIDAD
#Callback para actualizar grafico de cotizacion en funcion del dropdown 
#eligiendo apertura o cierre de sesion y segun selector de fechas
@app.callback(Output(...),
              [Input(...])
def actualizar_graph_line(fecha_min, fecha_max, seleccion):
    filtered_df = ... #Filtrar dataframe en base a fecha_min, fecha_max

    # Seleccionar fecha en funcion del dropdown "selector"
    if seleccion == "Open":
        return{
            ...





            )}

    else:
        return{
            ...





    }

#Callback para actualizar grafico de volumen segun selector de fechas
@app.callback(Output(...),
              [Input(...])
def actualizar_graph_bar(fecha_min, fecha_max):
    filtered_df = ... #Filtrar dataframe en base a fecha_min, fecha_max
    return{
        'data': [...],

        'layout': ...
            }

#Sentencias para abrir el servidor al ejecutar este script
if __name__ == '__main__':
    app.run_server()
