#Importar librerías
import dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd

#Carga de datos
df_temp = pd.read_excel(r'datasets\Temperaturas.xlsx')

df_temp.columns

df_temp.head(2)

app = dash.Dash()

#Definición del layout de la app a partir de componentes HTML y Core
app.layout = html.Div([
    dcc.DatePickerRange(id='selector_fecha',start_date=df_temp['FECHA'].min(),
                        end_date=df_temp['FECHA'].max()),
    #Seleccionamos todo el rango de fechas de nuestro dataframe
    dcc.Graph(id='graph_linea')
    #figure = data | layout

])

# CREACIÓN DE GRÁFICOS E INTERACTIVIDAD
#Callback para actualizar gráfico en función del rango de fechas seleccionadas
@app.callback(Output('graph_linea', 'figure'),
              [Input('selector_fecha', 'start_date'),
               Input('selector_fecha', 'end_date')])

def actualizar_graph(fecha_min, fecha_max):
    
    filtered_df = df_temp[(df_temp["FECHA"]>=fecha_min) & (df_temp["FECHA"]<=fecha_max)]

    #Creación de 1 traza por cada ciudad de nuestro dataframe
    traces = []
    df_ciudad_M = filtered_df[filtered_df['Ciudad'] == "Madrid"]
    df_ciudad_B = filtered_df[filtered_df['Ciudad'] == "Barcelona"]
    
    traces1 = go.Scatter(
            x=df_ciudad_M["FECHA"],
            y=df_ciudad_M["T_Promedio"],
            text=df_ciudad_M["Ciudad"], #"Madrid"
            mode='lines',
            opacity=0.7,
            marker={'size': 15},
            name="Madrid"
        )
    
    traces2 = go.Scatter(
            x=df_ciudad_B["FECHA"],
            y=df_ciudad_B["T_Promedio"],
            text=df_ciudad_B["Ciudad"], #"Barcelona"
            mode='lines',
            opacity=0.7,
            marker={'size': 15},
            name="Barcelona"
        )
    
    #traces.append(traces1)
    #traces.append(traces2)
    traces = [traces1,traces2]
    
    
    return { #Se retornan los objetos data y layout para ser enviados al Output con identificador graph_linea
        'data': traces,
        'layout': go.Layout(
            xaxis={'title': 'Fecha'},
            yaxis={'title': 'Temperatura media'},
            hovermode='closest'
        )
    }

#Sentencias para abrir el servidor al ejecutar este script
if __name__ == '__main__':
    app.run_server(port=7999)
